"use strict";(self.webpackChunklevel_game=self.webpackChunklevel_game||[]).push([[6795],{6795:(e,a,l)=>{l.r(a),l.d(a,{default:()=>t});l(9950);var s=l(5216),c=l(448),d=l(4431),n=l(2515),i=l(4752),r=l(4414);const x=i.Ay.div`
  display: flex;
  gap: 20px;
  justify-content: center;
  margin: 20px 0;
`,t=()=>(0,r.jsx)(c.Gy,{children:(0,r.jsx)(c.ee,{children:(0,r.jsxs)(s.A.Body,{children:[(0,r.jsx)(s.A.Title,{children:"Level 21 - Blackjack!"}),(0,r.jsxs)(x,{children:[(0,r.jsx)(n.A,{cardId:"ace-spades",forceAvailable:!0,value:"A"}),(0,r.jsx)(n.A,{cardId:"king-spades",forceAvailable:!0,value:"K"})]}),(0,r.jsx)(s.A.Text,{children:(0,r.jsx)(d.A,{text:"The perfect hand in Blackjack - Ace and King of Spades for 21!"})})]})})})}}]);