"use strict";(self.webpackChunklevel_game=self.webpackChunklevel_game||[]).push([[3957],{3957:(e,n,i)=>{i.r(n),i.d(n,{default:()=>u});var r=i(9950),l=i(4752),s=(i(6760),i(5216)),t=i(7937),a=i(448),d=i(4431),o=i(4414);const c=l.Ay.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
  margin: 1rem 0;
`,x=l.Ay.div`
  font-size: 24px;
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 0.5rem;
  margin: 1rem 0;
  text-align: center;
`,u=()=>{const[e,n]=(0,r.useState)(null);return(0,o.jsx)(a.Gy,{children:(0,o.jsx)(a.ee,{children:(0,o.jsxs)(s.A.Body,{children:[(0,o.jsx)(s.A.Title,{children:(0,o.jsx)(d.A,{text:"A Dozen Choices",size:"medium"})}),(0,o.jsx)(s.A.Text,{children:(0,o.jsx)(d.A,{text:"Would you like a dozen eggs or a dozen donuts?"})}),(0,o.jsx)(c,{children:e?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(d.A,{text:`Here's your dozen ${"\ud83e\udd5a"===e?"eggs":"donuts"}!`,size:"small"}),(0,o.jsx)(x,{children:(i=e,Array(12).fill(i).map(((e,n)=>(0,o.jsx)("span",{children:e},n))))}),(0,o.jsx)(t.A,{variant:"outline-secondary",onClick:()=>n(null),children:"Choose Again"})]}):(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(t.A,{variant:"outline-primary",onClick:()=>n("\ud83e\udd5a"),children:"Dozen Eggs \ud83e\udd5a"}),(0,o.jsx)(t.A,{variant:"outline-primary",onClick:()=>n("\ud83c\udf69"),children:"Dozen Donuts \ud83c\udf69"})]})})]})})});var i}}}]);