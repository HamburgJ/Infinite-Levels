"use strict";(self.webpackChunklevel_game=self.webpackChunklevel_game||[]).push([[3892],{3892:(e,t,s)=>{s.r(t),s.d(t,{default:()=>x});var o=s(9950),l=s(5216),i=s(448),r=s(4431),n=s(4752),a=s(4414);const h=n.Ay.div`
  width: 60px;
  height: 80px;
  background: #ff6b6b;
  border-radius: 50%;
  position: relative;
  margin: 30px auto;
  cursor: pointer;
  
  &:before {
    content: '';
    width: 2px;
    height: 30px;
    background: #666;
    position: absolute;
    bottom: -30px;
    left: 50%;
    transform: translateX(-50%);
  }
`,x=()=>{const[e,t]=(0,o.useState)(!1);return(0,a.jsx)(i.Gy,{children:(0,a.jsx)(i.ee,{children:(0,a.jsxs)(l.A.Body,{children:[(0,a.jsx)(l.A.Title,{children:"Level 55"}),(0,a.jsx)(l.A.Text,{children:(0,a.jsx)(r.A,{text:"Please don't pop this balloon. It's very special to me."})}),!e&&(0,a.jsx)(h,{onClick:()=>t(!0)}),e&&(0,a.jsx)(l.A.Text,{style:{color:"#666",fontStyle:"italic",marginTop:"20px"},children:(0,a.jsx)(r.A,{text:"*sigh* I really wish you hadn't done that..."})})]})})})}}}]);