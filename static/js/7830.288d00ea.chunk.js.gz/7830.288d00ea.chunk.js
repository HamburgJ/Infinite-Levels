"use strict";(self.webpackChunklevel_game=self.webpackChunklevel_game||[]).push([[7830],{7830:(e,t,a)=>{a.r(t),a.d(t,{default:()=>c});a(9950);var s=a(5216),l=a(4752),n=a(448),i=a(4431),r=a(4414);const o=l.Ay.div`
  font-size: 3rem;
  text-align: center;
  margin: 20px 0;
  animation: float 2s ease-in-out infinite;
  
  @keyframes float {
    0% { transform: translateY(0px); }
    50% { transform: translateY(-10px); }
    100% { transform: translateY(0px); }
  }
`,c=()=>(0,r.jsx)(n.Gy,{children:(0,r.jsx)(n.ee,{children:(0,r.jsxs)(s.A.Body,{children:[(0,r.jsx)(s.A.Title,{children:(0,r.jsx)(i.A,{text:"Octo-Level",size:"medium"})}),(0,r.jsx)(s.A.Text,{children:(0,r.jsx)(i.A,{text:"Eight sides make an octagon, and eight arms make an octopus! What makes level 88? Two circles stacked on top of each other!"})}),(0,r.jsx)(o,{children:"\ud83d\udc19"}),(0,r.jsx)(s.A.Text,{children:(0,r.jsx)(i.A,{text:"Fun fact: Octopi are known to be highly intelligent and can solve puzzles. Maybe this little guy could help navigate through all these levels!"})})]})})})}}]);