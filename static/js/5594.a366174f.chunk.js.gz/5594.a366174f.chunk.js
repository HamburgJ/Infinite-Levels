"use strict";(self.webpackChunklevel_game=self.webpackChunklevel_game||[]).push([[5594],{5594:(e,l,i)=>{i.r(l),i.d(l,{default:()=>d});i(9950);var n=i(5216),s=i(448),t=i(4431),r=i(4752),o=i(4414);const c=r.Ay.div`
  color: #dc3545;
  font-weight: bold;
  text-align: center;
  margin: 10px 0;
`,a=r.Ay.span`
  font-size: 1.5em;
  margin: 0 5px;
`,d=()=>(0,o.jsx)(s.Gy,{children:(0,o.jsx)(s.ee,{children:(0,o.jsxs)(n.A.Body,{children:[(0,o.jsx)(n.A.Title,{children:"Level 62"}),(0,o.jsxs)(c,{children:[(0,o.jsx)(a,{children:"\ud83d\udc1b"}),(0,o.jsx)(t.A,{text:"NOTICE: This level is temporarily closed for pest control"}),(0,o.jsx)(a,{children:"\ud83d\udc1c"})]}),(0,o.jsx)(n.A.Text,{children:(0,o.jsx)(t.A,{text:"We apologize for any inconvenience. Our pest control team is working diligently to resolve the issue. Please visit another level until maintenance is complete."})})]})})})}}]);