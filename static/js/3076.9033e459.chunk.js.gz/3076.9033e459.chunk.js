"use strict";(self.webpackChunklevel_game=self.webpackChunklevel_game||[]).push([[3076],{3076:(e,t,n)=>{n.r(t),n.d(t,{default:()=>i});var r=n(9950),a=n(5216),s=n(448),o=n(4752),l=n(4414);const m=o.i7`
  0% { transform: translate(0) }
  20% { transform: translate(-2px, 2px) }
  40% { transform: translate(-2px, -2px) }
  60% { transform: translate(2px, 2px) }
  80% { transform: translate(2px, -3px) rotate(3deg) }
  100% { transform: translate(0) }
`,d=o.Ay.div`
  animation: ${m} 0.3s infinite;
  color: red;
  text-shadow: 2px 2px blue, -2px -2px green;
  font-family: monospace;
  font-size: 2em;
`,i=()=>{const[e,t]=(0,r.useState)(!1);return(0,r.useEffect)((()=>{const e=setInterval((()=>{t((e=>!e)),Math.random()<.1&&(document.body.style.filter="invert(100%)",setTimeout((()=>{document.body.style.filter="none"}),200+1e3*Math.random()))}),200+1e3*Math.random());return()=>clearInterval(e)}),[]),(0,l.jsx)(s.Gy,{children:(0,l.jsx)(s.ee,{style:{transform:e?"skew(-20deg)":"none"},children:(0,l.jsxs)(a.A.Body,{children:[(0,l.jsx)(d,{children:"ERROR 404: LEVEL NOT FOUND"}),(0,l.jsx)(a.A.Text,{style:{fontFamily:"monospace"},children:"SYSTEM MALFUNCTION... REALITY BREACH DETECTED..."})]})})})}}}]);