"use strict";(self.webpackChunklevel_game=self.webpackChunklevel_game||[]).push([[9879],{9879:(e,r,l)=>{l.r(r),l.d(r,{default:()=>u});var t=l(9950),s=l(4752),i=l(300),a=l(6760),n=l(5216),c=l(1283),d=l(112),v=l(448),h=l(4414);const x=(0,s.Ay)(v.Gy)`
  transform: scaleY(-1); // Invert the entire level!
`,o=(0,s.Ay)(n.A)`
  background: rgba(0, 0, 0, 0.9);
  backdrop-filter: blur(10px);
  border: 2px solid rgba(255, 255, 255, 0.1);
  color: white;
`,j=s.Ay.div`
  transform: scaleY(-1);
`,u=()=>{const e=(0,i.wA)();return t.useEffect((()=>{e((0,a._e)("negativeNumbers"))}),[e]),(0,h.jsx)(x,{children:(0,h.jsx)(o,{children:(0,h.jsxs)(n.A.Body,{children:[(0,h.jsx)(n.A.Title,{children:(0,h.jsx)(j,{children:(0,h.jsx)(d.A,{text:"Level 14 - Negative Space",size:"medium"})})}),(0,h.jsxs)(n.A.Text,{children:[(0,h.jsx)(j,{children:(0,h.jsx)(d.A,{text:"These levels are similar to the positive numbered levels, but have a strange inversion to their properties..."})}),(0,h.jsx)(j,{children:(0,h.jsx)(d.A,{text:"Did you know? There are also negative numbered levels..."})})]}),(0,h.jsxs)("div",{className:"d-flex justify-content-center flex-wrap",children:[(0,h.jsx)(c.A,{targetLevel:-1,variant:"light",children:"Level -1"}),(0,h.jsx)(c.A,{targetLevel:-5,variant:"light",children:"Level -5"}),(0,h.jsx)(c.A,{targetLevel:-14,variant:"light",children:"Level -14"})]})]})})})}}}]);