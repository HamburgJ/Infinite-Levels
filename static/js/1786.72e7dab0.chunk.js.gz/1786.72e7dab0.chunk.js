"use strict";(self.webpackChunklevel_game=self.webpackChunklevel_game||[]).push([[1786],{1786:(e,t,s)=>{s.r(t),s.d(t,{default:()=>p});var i=s(9950),n=s(4752),a=s(5216),r=s(448),o=s(4431),l=s(1283),d=s(4414);const x=n.i7`
  from { opacity: 0; }
  to { opacity: 1; }
`,c=n.Ay.div`
  position: fixed;
  inset: 0;
  background: black;
  opacity: ${e=>e.darkness};
  transition: opacity 2s ease;
  pointer-events: none;
  z-index: 50;
`,h=n.Ay.div`
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  animation: ${x} 3s ease-in;
  z-index: 1000;
`,u=n.Ay.div`
  position: fixed;
  bottom: 70px;
  left: 120px;
  font-size: 48px;
  opacity: ${e=>e.show?.05:0};
  transition: opacity 2s ease-in-out;
  z-index: 1000;
`,p=()=>{const[e,t]=(0,i.useState)(1),[s,n]=(0,i.useState)(!1),[x,p]=(0,i.useState)(!1),[j,f]=(0,i.useState)(""),v="... The dog was inside you all along!";return(0,i.useEffect)((()=>{setTimeout((()=>{const e=setInterval((()=>{t((t=>{if(t<=0){clearInterval(e),n(!0);let t=0;const s=setInterval((()=>{t<37?(f((e=>e+v[t])),t++):(clearInterval(s),p(!0))}),100);return 0}return t>.8?.98*t:t-.05}))}),500)}),1e3)}),[]),(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(c,{darkness:e}),(0,d.jsx)(r.Gy,{children:(0,d.jsx)(r.ee,{children:(0,d.jsxs)(a.A.Body,{children:[(0,d.jsx)(a.A.Title,{children:(0,d.jsx)(o.A,{text:"Level 13 - Are you afraid?",size:"medium"})}),(0,d.jsx)(a.A.Text,{children:(0,d.jsx)(o.A,{text:"The darkness is coming..."})}),(0,d.jsx)(a.A.Text,{children:(0,d.jsx)(o.A,{text:"They say bad things happen in the dark...",size:"small"})}),(0,d.jsx)(a.A.Text,{children:(0,d.jsx)(o.A,{text:`${j}`})})]})})}),x&&(0,d.jsx)(u,{show:x,children:"\ud83d\udc36"}),s&&(0,d.jsx)(h,{children:(0,d.jsx)(l.A,{targetLevel:0,variant:"outline-warning",children:"Return to the Light at Level 0"})})]})}}}]);